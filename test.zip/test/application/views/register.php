<!DOCTYPE html>
<html lang="en">


<head>
    <meta charset="utf-8" />
    <title>SIPL</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="A fully featured admin theme which can be used to build CRM, CMS, etc." name="description" />
    <meta content="Coderthemes" name="author" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="assets/images/favicon.ico">

    <!-- App css -->
    <link href="<?php echo base_url(); ?>assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo base_url(); ?>assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo base_url(); ?>assets/css/app.min.css" rel="stylesheet" type="text/css" />

</head>

<body>

    <div class="account-pages mt-5 mb-5">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8 col-lg-6 col-xl-7">
                    <div class="card">

                        <div class="card-body p-4">

                            <div class="text-center w-75 m-auto">
                                <a href="">
                                    <span> <img src="<?php echo base_url(); ?>assets/images/logo-light.jpg" alt="" height="50"></span>
                                </a>
                                <p class="text-muted mb-4 mt-3">Don't have an account? Create your own account, it takes less than a minute</p>
                            </div>

                            <form method="post" action="<?php echo base_url('Home/register_insert'); ?>">

                                <div class="form-group row">
                                    <div class="col-4">
                                        <label for="first_name">First Name</label>
                                        <input class="form-control" type="text" id="first_name" name="first_name" placeholder="Enter your first name" required>
                                    </div>
                                    <div class="col-4">
                                        <label for="middle_name">Middle Name</label>
                                        <input class="form-control" type="text" id="middle_name" name="middle_name" placeholder="Enter your middle name" required>
                                    </div>
                                    <div class="col-4">
                                        <label for="last_name">Last Name</label>
                                        <input class="form-control" type="text" id="last_name" name="last_name" placeholder="Enter your last name" required>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <div class="col-4">
                                        <label for="dob">DOB</label>
                                        <input class="form-control" type="text" id="dob" name="dob" placeholder="Enter your birthdate" required>
                                    </div>
                                    <div class="col-4">
                                        <label for="gender">Gender</label>
                                        <select class="form-control" type="text" id="gender" name="gender" placeholder="Enter your gender">
                                            <option value="1">Male</option>
                                            <option value="2">Female</option>
                                        </select>
                                    </div>
                                    <div class="col-4">
                                        <label for="contact_number">Contact Number</label>
                                        <input class="form-control" type="text" id="contact_number" name="contact_number" placeholder="Enter your contact no" required>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="email">Email address</label>
                                    <input class="form-control" type="email" id="email" name="email" required placeholder="Enter your email">
                                </div>

                                 <div class="form-group row">
                                    <div class="col-6">
                                        <label for="address_one">Address</label>
                                        <textarea class="form-control" type="text" id="address_one" name="address_one" placeholder="Enter your address"></textarea>
                                    </div>
                                    <div class="col-6">
                                        <label for="address_two">Address2</label>
                                        <textarea class="form-control" type="text" id="address_two" name="address_two" placeholder="Enter your address"></textarea>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <div class="col-4">
                                        <label for="city">City</label>
                                        <input class="form-control" type="text" id="city" name="city" placeholder="Enter City" required>
                                    </div>
                                    <div class="col-4">
                                        <label for="state">State</label>
                                        <input class="form-control" type="text" id="state" name="state" placeholder="Enter State" required>
                                    </div>
                                    <div class="col-4">
                                        <label for="zipcode">Zipcode</label>
                                        <input class="form-control" type="text" id="zipcode" name="zipcode" placeholder="Enter Zipcode" required>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="password">Password</label>
                                    <input class="form-control" type="password" required id="password" name="password" placeholder="Enter your password">
                                </div>
                                
                                <div class="form-group row">
                                    <div class="col-6">
                                        <label for="login_type">Login Type</label>
                                        <input class="form-control" type="text" id="login_type" name="login_type" placeholder="Enter Login Type" required>
                                    </div>
                                    <div class="col-6">
                                        <label for="ssn_digits">SSN Digits</label>
                                        <input class="form-control" type="text" id="ssn_digits" name="ssn_digits" placeholder="Enter SSN Digits" required>
                                    </div>
                                </div>

                                <div class="form-group mb-0 text-center">
                                    <button class="btn btn-primary btn-block" type="submit"> Sign Up </button>
                                </div>

                            </form>

                            <div class="text-center">
                                <h5 class="mt-3 text-muted">Sign up using</h5>
                                <ul class="social-list list-inline mt-3 mb-0">
                                    <li class="list-inline-item">
                                        <a href="javascript: void(0);" class="social-list-item border-primary text-primary"><i class="mdi mdi-facebook"></i></a>
                                    </li>
                                    <li class="list-inline-item">
                                        <a href="javascript: void(0);" class="social-list-item border-danger text-danger"><i class="mdi mdi-google"></i></a>
                                    </li>
                                    <li class="list-inline-item">
                                        <a href="javascript: void(0);" class="social-list-item border-info text-info"><i class="mdi mdi-twitter"></i></a>
                                    </li>
                                    <li class="list-inline-item">
                                        <a href="javascript: void(0);" class="social-list-item border-secondary text-secondary"><i class="mdi mdi-github-circle"></i></a>
                                    </li>
                                </ul>
                            </div>

                        </div> <!-- end card-body -->
                    </div>
                    <!-- end card -->

                    <div class="row mt-3">
                        <div class="col-12 text-center">
                            <p class="text-muted">Already have account? <a href="<?php echo base_url() ?>" class="text-muted font-weight-medium ml-1">Sign In</a></p>
                        </div> <!-- end col -->
                    </div>
                    <!-- end row -->

                </div> <!-- end col -->
            </div>
            <!-- end row -->
        </div>
        <!-- end container -->
    </div>
    <!-- end page -->


    <footer class="footer footer-alt">
        2016 - 2019 &copy;<a href="#" class="text-muted">SIPL</a>
    </footer>

    <!-- Vendor js -->
    <script src="<?php echo base_url(); ?>assets/js/vendor.min.js"></script>

    <!-- App js -->
    <script src="<?php echo base_url(); ?>assets/js/app.min.js"></script>

</body>


</html>
