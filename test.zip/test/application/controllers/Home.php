<?php
	defined('BASEPATH') OR exit('No direct script access allowed');

	class Home extends CI_Controller {

		public function __construct(){

			parent::__construct();

				$this->load->helper(array('form', 'url'));
            	$this->load->library('form_validation');
            	$this->load->library('session');
			}

		public function index()
		{			
			$this->load->view('login');
		}

		// <!--	REGISTER PAGE	-->

		public function register()
		{			
			$this->load->view('register');
		}

		// <!--	USER REGISTER	-->

		public function register_insert()
		{
			$this->form_validation->set_rules('first_name', 'First Name', 'required');
			$this->form_validation->set_rules('middle_name', 'Middle Name', 'required');
			$this->form_validation->set_rules('last_name', 'Last Name', 'required');
			$this->form_validation->set_rules('dob', 'Date of Birth', 'required');
            $this->form_validation->set_rules('gender', 'Gender', 'required');
            $this->form_validation->set_rules('contact_number', 'Contact Number', 'required');
            $this->form_validation->set_rules('email', 'Email', 'required');
            $this->form_validation->set_rules('password', 'Password', 'required');
                      
            if ($this->form_validation->run() == FALSE)
            {
            	redirect(base_url());            	
            }
            else
            {
	            $url = 'https://softonauts.com/clients/Android/register-user';
            	
            	$first_name 	= $this->input->post('first_name');
            	$middle_name 	= $this->input->post('middle_name');
            	$last_name 		= $this->input->post('last_name');
            	$dob 			= date('d-m-Y', strtotime($this->input->post('dob')));
            	$gender 		= $this->input->post('gender');
            	$contact_number = $this->input->post('contact_number');
            	$email 			= $this->input->post('email');
            	$address_one 	= $this->input->post('address_one');
            	$address_two 	= $this->input->post('address_two');
            	$city 			= $this->input->post('city');
            	$state 			= $this->input->post('state');
            	$zipcode		= $this->input->post('zipcode');
            	$password 		= $this->input->post('password');
            	$login_type 	= $this->input->post('login_type');
            	$ssn_digits 	= $this->input->post('ssn_digits');
            	
    			$data = [
	        		'first_name'=>$first_name,
	        		'middle_name'=>$middle_name,
	        		'last_name'=>$last_name,
	        		'dob'=>$dob,
	        		'gender'=>$gender,
	        		'contact_number'=>$contact_number,
	        		'email'=>$email,
	        		'address_one'=>$address_one,
	        		'address_two'=>$address_two,
	        		'city'=>$city,
	        		'state'=>$state,
	        		'zipcode'=>$zipcode,
	        		'password'=> sha1($password),
	        		'login_type'=>$login_type,
	        		'ssn_digits'=>$ssn_digits
        		];
        		
        		$result = $this->api_method($url, $data);

        		$data = json_decode(json_encode($result), true);
        		            				
    			if($data['code'] == 200)
        		{
        			$this->load->view('dashboard');
        		}else
        		{
        			echo "error";
        		}
            }
		}

		// <!--	USER LOGIN	-->

		public function login_action()
		{
			$this->load->library('session');

			$this->form_validation->set_rules('username', 'Username', 'required');
            $this->form_validation->set_rules('password', 'Password', 'required');
               

            if ($this->form_validation->run() == FALSE)
            {
            	redirect(base_url());            	
            }
            else
            {
	            $url = 'https://softonauts.com/clients/Android/users-login';
            	$username = $this->input->post('username');
            	$password = $this->input->post('password');
            	
            	if($username == "JohnKHester@jourrapide.com")
            	{
            		if($password == "Password1")
            		{
            			$data = [
	            		'username'=>'JohnKHester@jourrapide.com',
	            		'password'=>'Password1',
	            		'fcm_id' => ''
	            		];	

	            		$result = $this->api_method($url, $data);

	            		$data = json_decode(json_encode($result), true);
	            		            				
            			if($data['code'] == 200)
	            		{
	            			$session_data = array(
	            				'id' => $data['data']['id'], 
	            				'first_name' => $data['data']['first_name'], 
	            				'middle_name' => $data['data']['middle_name'], 
	            				'last_name' => $data['data']['last_name'], 
	            				'contact_number' => $data['data']['contact_number'], 
	            				'email' => $data['data']['email'], 
	            				'gender' => $data['data']['gender'], 
	            				'gender_name' => $data['data']['gender_name'], 
	            				'login_type' => $data['data']['login_type'], 
	            				'del_status' => $data['data']['del_status'],
	            				'session_token' => $data['session_token']
	            			);

	            			$this->session->set_userdata($session_data);

	            			redirect(base_url().'home/dashboard');
	            		}
            		}
            		else
            		{
            			$this->session->set_flashdata('message', 'Please Enter Correct Password');
            			redirect(base_url());	
            		}
            		
            	}
            	else
            	{
            		
            		log_message('error', 'Some variable did not contain a value.');
            		$this->session->set_flashdata('message', 'Please Enter Correct Username');
            		redirect(base_url());
            	}
            }
		}

		// <!--	DASHBOARD PAGE	-->

		public function dashboard()
		{
			if ($this->session->userdata('id') != "")
			{
				$url = 'https://softonauts.com/clients/Android/get-drop-in-navigator-list';

				$id = $this->session->userdata('id');

				$data = [
	            			'user_id' => $id
	            		];	

	            $result = $this->api_method($url, $data);

	            $data = json_decode(json_encode($result), true);
	           
				$this->load->view('dashboard');
			}
			else
			{
				redirect(base_url());
			}	
		}

		
		// <!--	KIT REQUEST PAGE	-->

		public function kit_request()
		{
			if ($this->session->userdata('id') != "")
			{
				$url = 'https://softonauts.com/clients/Android/get-time-slots';

				$id = $this->session->userdata('id');

				$data = [
	            			'location_id' => 16
	            		];	

	            $result = $this->api_method($url, $data);

	            $data = json_decode(json_encode($result), true);
	           
				$this->load->view('kit_request');
			}
			else
			{
				redirect(base_url());
			}	
		}


		// =========================================
		public function api_method($url, $data)
	    {

	        // $url = 'https://softonauts.com/clients/Android/users-login';

	       	$ch = curl_init();

	        /* Array Parameter Data */

	        // $data = ['username'=>'JohnKHester@jourrapide.com', 'password'=>'Password1','fcm_id' => ''];

	        /* pass encoded JSON string to the POST fields */
	        curl_setopt($ch, CURLOPT_URL, $url);
	        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
	        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
	        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
	                'Authorization: Basic eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpZCI6MX0.By2r2BwheJsbrEGrHOaMQwrrmlY7wHVFzWtuEmv39fM'
	            ));
	        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

	        /* execute request */

	        $result = curl_exec( $ch );
			$result1 = json_decode($result);
			
			return $result1;

	        /* close cURL resource */

	        curl_close($ch);

	    }
		// =========================================
	}
?>